#动态网站的特征
#登录问题 验证码问题 ip限制 js数据加密，屏蔽

#为什么设置反扒机制：1 保护网站的数据安全 2 保护网站本身的安全（大量的代理ip访问会导致网站瘫痪）

#反反爬：1 伪装浏览器 2使用代理ip 3抓包分析 4 实验selenium等

#seleenium是一个web应用程序测试工具，直接运行在浏览器中，模仿人工操作
#支持浏览器：le，谷歌，火狐，safari
#自动化测试，js动态爬虫


#京东网址：https://www.jd.com/

from selenium import webdriver
import pandas as pd
import gettime
import utlis

from selenium.webdriver.common.keys import Keys


good_list=[]
# 1.模拟浏览器访问京东页面，解决爬虫
def spider(url, keyword):  # 定义函数，封装代码
    utlis.delet()
    driver=webdriver.Firefox()  # 初始化一个浏览器
    driver.get(url)
    # time.sleep(5)
    print(keyword)
    try:
        driver.implicitly_wait(5)  # 隐式等待，确保节点完全加载出来
        input_tug = driver.find_element_by_id('key')  # 定位搜索栏
        input_tug.send_keys(keyword)  # 模拟键盘输入关键字
        input_tug.send_keys(Keys.ENTER)  # 回车键
        get_goods(driver)

    finally:
        driver.close()  # 关闭


# 2.定位商品数据抓取
def get_goods(driver):
    try:  # 商品名字、href、价格、评论

        goods = driver.find_elements_by_class_name('gl-item')  # 定位每一件商品

        for good in goods:  # 遍历商品信息
            p_name = good.find_element_by_css_selector('.p-name em').text.replace('\n', '')  # 商品名字
            detail_url = good.find_element_by_tag_name('a').get_attribute('href')  # href链接
            price = good.find_element_by_css_selector('.p-price i').text  # 价格
            p_commit = good.find_element_by_css_selector('.p-commit a').text  # 评论
            msg = '''
            商品:%s
            链接:%s
            价格:%s
            评论:%s
            ''' % (p_name, detail_url, price, p_commit)
            print(msg)
            utlis.insert_tabel(p_name, detail_url, price, p_commit)




        # 3.爬取大量数据
        button = driver.find_element_by_partial_link_text('下一页')  # 定位到这个元素
        button.click()  # 点击
        gettime.sleep(2)
        get_goods(driver)


    except Exception:
        pass


if __name__=="__main__":
    spider('https://www.jd.com/','diy红绳珍珠庄梦蝶')