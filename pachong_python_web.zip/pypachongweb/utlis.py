import gettime
import pymysql
from dataclasses import dataclass
def get_time():
    time_str=gettime.strftime("%Y{}%m{}%d{} %X")
    return time_str.format("年","月","日")


def get_con():
    conn = pymysql.Connect(host="127.0.0.1", port=3306, user="root", password="123", db="zpp", charset="utf8",
                           cursorclass=pymysql.cursors.DictCursor)
    cursor=conn.cursor()
    return conn,cursor

def close_con(conn,cursor):
    cursor.close()
    conn.close()

def query(sql,*args):
    conn,cursor=get_con()
    cursor.execute(sql,args)
    res=cursor.fetchall()#查询
    print(res)
    close_con(conn,cursor)#关闭
    return res
def creat(sql,val):
    conn, cursor = get_con()
    cursor.execute(sql, val)
    close_con(conn, cursor)  # 关闭
def insert(sql,val,*args):
    conn, cursor = get_con()
    cursor.execute(sql,val)
    value=cursor.fetchall()
    print(value)
    conn.commit()
    conn.close()

def delet():
    conn,cursor=get_con()
    cursor.execute("DELETE FROM db_table")
    close_con(conn,cursor)

def deletlagou():
    conn, cursor = get_con()
    cursor.execute("DELETE FROM db_lagou")
    close_con(conn, cursor)

def deletmaoyan():
    conn, cursor = get_con()
    cursor.execute("DELETE FROM db_maoyan")
    close_con(conn, cursor)
#db_new
def deletnew():
    conn, cursor = get_con()
    cursor.execute("DELETE FROM db_new")
    close_con(conn, cursor)

def show():
    conn, cursor = get_con()
    # get annual sales rank
    sql = "select * from db_table"
    cursor.execute(sql)
    content = cursor.fetchall()

    # 获取表头
    sql = "SHOW FIELDS FROM db_table"
    cursor.execute(sql)
    return cursor.fetchall(),content

@dataclass
class User:
    id:int
    username:str
    password:str

def getItems():
    conn, cursor = get_con()
    sql = "select * from db_table"
    cursor.execute(sql)
    items = cursor.fetchall()
    print(items)
    return items

def getItems_lagou():
    conn, cursor = get_con()
    sql = "select * from db_lagou"
    cursor.execute(sql)
    items = cursor.fetchall()
    print(items)
    return items
#db_maoyan
def getItems_maoyan():
    conn, cursor = get_con()
    sql = "select * from db_maoyan"
    cursor.execute(sql)
    items = cursor.fetchall()
    print(items)
    return items
#db_new
def getItems_new():
    conn, cursor = get_con()
    sql = "select * from db_new"
    cursor.execute(sql)
    items = cursor.fetchall()
    print(items)
    return items

def get_userdata():
    conn, cursor = get_con()
    sql = "select * from tb_user"
    cursor.execute(sql)
    items = cursor.fetchall()
    print(items)
    return items


def get_data():
    users = []
    sql="SELECT *FROM tb_user"
    res=query(sql)
    for line in res:
       # print(line['序号'],line['username'],line['password'])
        user=User(int(line['序号']),str(line['username']),str(line['password']))
        users.append(user)
    return users



def creat_table(tablename):
    sql="""CREATE TABLE %s(
	good VARCHAR(230),
	href VARCHAR(230),
	price VARCHAR(230),
	review VARCHAR(230)
)"""
    val=tablename
    creat(sql,val)

def insert_tabel(p_name, detail_url, price, p_commit):
    sql="INSERT INTO db_table (good,href,price,review) VALUES (%s,%s,%s,%s)"
    val=(p_name, detail_url, price, p_commit)
    insert(sql,val)

def insert_lagou(p_name,detail_url,gongsi,gongzi):
    sql = "INSERT INTO db_lagou (position_name,detail_url,company,wages_education) VALUES (%s,%s,%s,%s)"
    val = (p_name, detail_url, gongsi, gongzi)
    insert(sql, val)
#db_maoyan

def insert_maoyan(p_name,detail_url,movetime):
    sql = "INSERT INTO db_maoyan (movie,actor,movietime) VALUES (%s,%s,%s)"
    val = (p_name, detail_url,movetime)
    insert(sql, val)

#db_new
def insert_new(p_name,detail_url):
    sql = "INSERT INTO db_new (new_name,new_herf) VALUES (%s,%s)"
    val = (p_name, detail_url)
    insert(sql, val)

def insert_user(username,passeord):
    sql="INSERT INTO tb_user (username,password) VALUES (%s,%s)"
    val=(username,passeord)
    insert(sql,val)

def user_alter(password,username):
    sql="UPDATE tb_user SET PASSWORD=%s WHERE username=%s"#UPDATE tb_user SET PASSWORD='12' WHERE username='zpp'
    val=(password,username)
    #print(sql,val)
    conn, cursor = get_con()
    result = cursor.execute(sql, val)
    #print(result)
    conn.commit()
    cursor.close()
    conn.close()

def user_delet(username):
    sql="DELETE FROM tb_user WHERE username=%s"#UPDATE tb_user SET PASSWORD='12' WHERE username='zpp'
    val=(username)
    #print(sql,val)
    conn, cursor = get_con()
    result = cursor.execute(sql, val)
    #print(result)
    conn.commit()
    cursor.close()
    conn.close()

if __name__=="__main__":
    user_delet('qw')


