
from selenium import webdriver
import pandas as pd
import gettime
import utlis
from selenium.webdriver.common.keys import Keys


good_list=[]
# 1.模拟浏览器访问京东页面，解决爬虫
def spider(url, keyword):  # 定义函数，封装代码
    utlis.deletlagou()
    driver=webdriver.Firefox()  # 初始化一个浏览器
    driver.get(url)
    # time.sleep(5)
    try:
        driver.implicitly_wait(5)  # 隐式等待，确保节点完全加载出来
        button = driver.find_element_by_partial_link_text('全国')  # 定位到这个元素
        button.click()  # 点击
        driver.implicitly_wait(3)
        input_tug = driver.find_element_by_id('search_input')  # 定位搜索栏
        input_tug.send_keys(keyword)  # 模拟键盘输入关键字
        input_tug.send_keys(Keys.ENTER)  # 回车键
        get_goods(driver)

    finally:
        driver.close()  # 关闭


# 2.定位商品数据抓取
def get_goods(driver):
    try:  # 商品名字、href、价格、评论
        goods = driver.find_elements_by_class_name('con_list_item')  # 定位每一件商品
        for good in goods:  # 遍历商品信息
            p_name = good.find_element_by_css_selector('.p_top h3').text.replace('\n', '')  # 商品名字
            detail_url = good.find_element_by_tag_name('a').get_attribute('href')  # href链接
            gongsi = good.find_element_by_css_selector('.company_name a').text  # 价格
            gongzi = good.find_element_by_css_selector('.li_b_l').text  # 评论
            msg = '''
            职位名称:%s
            链接：%s
            公司名称:%s
            工资/学历要求:%s
            ''' % (p_name, detail_url,gongsi, gongzi)
            utlis.insert_lagou(p_name,detail_url,gongsi,gongzi)

        # 3.爬取大量数据
        driver.find_element_by_class_name('pager_next ').click()  # 定位到这个元素
        gettime.sleep(2)
        get_goods(driver)
    except Exception:
        pass


if __name__ == '__main__':  # 判断文件程序入口
    spider('https://www.lagou.com/', keyword='高级人工智能算法工程师')
