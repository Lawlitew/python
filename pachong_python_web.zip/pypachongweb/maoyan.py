from selenium import webdriver
import pandas as pd
import gettime
import utlis
from selenium.webdriver.common.keys import Keys


good_list=[]
# 1.模拟浏览器访问京东页面，解决爬虫
def spider(url):  # 定义函数，封装代码
    utlis.deletmaoyan()
    driver=webdriver.Firefox()  # 初始化一个浏览器
    driver.get(url)
    # time.sleep(5)
    try:
        driver.implicitly_wait(5)  # 隐式等待，确保节点完全加载出来
        button = driver.find_element_by_partial_link_text('TOP100榜')  # 定位到这个元素
        button.click()  # 点击
        driver.implicitly_wait(3)
        get_goods(driver)

    finally:
        driver.close()  # 关闭


# 2.定位商品数据抓取
def get_goods(driver):
    try:  # 商品名字、href、价格、评论
        goods = driver.find_elements_by_class_name('movie-item-info')  # 定位每一件商品
        for good in goods:  # 遍历商品信息
            p_name = good.find_element_by_css_selector('.name a').text  # 商品名字
            #print(p_name)
            yanyuan = good.find_element_by_css_selector('.star').text  # 价格
           # print(yanyuan)
            shijian = good.find_element_by_css_selector('.releasetime').text  # 价格
            #print(shijian)
            msg = '''
                电影名称:%s
                %s
                上映时间：%s
                ''' % (p_name, yanyuan,shijian)
            print(msg)
            utlis.insert_maoyan(p_name, yanyuan,shijian)

        # 3.爬取大量数据
        driver.find_element_by_class_name('page_2 ').click()  # 定位到这个元素
        gettime.sleep(2)
        get_goods(driver)
    except Exception:
        pass


if __name__ == '__main__':  # 判断文件程序入口
    spider('https://maoyan.com/board/4')
