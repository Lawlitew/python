from selenium import webdriver
import pandas as pd
import gettime
import utlis
from selenium.webdriver.common.keys import Keys


good_list=[]
# 1.模拟浏览器访问京东页面，解决爬虫
def spider(url):  # 定义函数，封装代码
    utlis.deletnew()
    driver=webdriver.Firefox()  # 初始化一个浏览器
    driver.get(url)
    # time.sleep(5)
    try:
        driver.implicitly_wait(5)  # 隐式等待，确保节点完全加载出来
        get_goods(driver)

    finally:
        driver.close()  # 关闭


# 2.定位商品数据抓取
def get_goods(driver):
    try:  # 商品名字、href、价格、评论
        goods = driver.find_elements_by_class_name('feed-card-item')  # 定位每一件商品
        for good in goods:  # 遍历商品信息
            p_name = good.find_element_by_css_selector('h2').text  # 商品名字
            detail_url = good.find_element_by_tag_name('.undefined a').get_attribute('href')  # href链接
            msg = '''
                新闻名称:%s
                新闻链接：%s
                ''' % (p_name, detail_url)
            print(msg)
            utlis.insert_new(p_name,detail_url)

        # 3.爬取大量数据
        driver.find_element_by_class_name('pagebox_next ').click()  # 定位到这个元素
        gettime.sleep(2)
        get_goods(driver)
    except Exception:
        pass


if __name__ == '__main__':  # 判断文件程序入口
    spider('https://news.sina.com.cn/china/')
